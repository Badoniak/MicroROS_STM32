// generated from rosidl_generator_c/resource/idl.h.em
// with input from control_msgs:action/PointHead.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__ACTION__POINT_HEAD_H_
#define CONTROL_MSGS__ACTION__POINT_HEAD_H_

#include "control_msgs/action/detail/point_head__struct.h"
#include "control_msgs/action/detail/point_head__functions.h"
#include "control_msgs/action/detail/point_head__type_support.h"

#endif  // CONTROL_MSGS__ACTION__POINT_HEAD_H_
